import { describe, expect, it } from "vitest";
import { buildCaseEvidence, caseEvidenceIssues, reviewChapterCaseEvidence } from "./caseEvidence.js";
import { evidenceFixture, scriptedDevelopmentModel } from "./testing/bookDevelopmentFixtures.js";

const packet = evidenceFixture();
const candidate = { claims: packet.claims, sequence: packet.sequence, disagreements: [], unknowns: packet.unknowns };
const verdict = { caseMatch: { supported: true, reason: "The passage documents the trial", canonicalEpisode: packet.episode, anchors: [{ excerptId: packet.excerpts[0]!.id, quote: packet.excerpts[0]!.text }] }, sequenceReason: "The record explicitly says later", disagreementsReason: "No disagreement asserted", unknownsReason: "No dialogue in the passage", claims: packet.claims.map(({ id }) => ({ id, supported: true, reason: "Supported by the record" })), sequenceSupported: true, disagreementsSupported: true, unknownsAccurate: true };

function build(responses: unknown[], excerpts = packet.excerpts) {
  const { model, calls } = scriptedDevelopmentModel(responses);
  return { calls, result: buildCaseEvidence({ id: packet.id, chapterIndex: 1, episode: packet.episode, excerpts, textModel: model }) };
}

describe("reviewed case evidence", () => {
  it("will not substitute a model's memory for a missing retrieved passage", async () => {
    const { result, calls } = build([], []);
    expect(await result).toEqual({ failure: "no retrieved passage about this case" });
    expect(calls).toHaveLength(0);
  });

  it("retains exact source text, documented sequence and unknowns after a complete independent review", async () => {
    const { result, calls } = build([candidate, verdict]);
    expect(await result).toEqual({ packet });
    expect(calls.map((call) => call.purpose)).toEqual(["build-case-evidence", "verify-case-evidence"]);
    expect(JSON.parse(calls[1]!.messages[1]!.content).excerpts).toEqual(packet.excerpts);
  });

  it("rejects the reversed verdict that a plausible narrative could otherwise repeat", async () => {
    const { result } = build([
      { ...candidate, claims: [{ ...packet.claims[0]!, text: "The first jury found for the insurers." }, packet.claims[1]] },
      { ...verdict, claims: [{ id: "initial", supported: false, reason: "The record says shipowners, not insurers." }, verdict.claims[1]] }
    ]);
    expect((await result).failure).toContain("shipowners, not insurers");
  });

  it("rejects an incidental biography even when its individual claims are true", async () => {
    const { result } = build([candidate, {
      ...verdict,
      caseMatch: { supported: false, reason: "The passages concern the author's biography, not the proposed trial.", canonicalEpisode: packet.episode, anchors: [] }
    }]);
    expect((await result).failure).toContain("not the proposed trial");
  });

  it("requires the case review's anchors to resolve to the actual passage", async () => {
    const invalid = { ...verdict, caseMatch: { ...verdict.caseMatch, anchors: [{ excerptId: "record", quote: "The source never said this." }] } };
    const { result } = build([candidate, invalid, invalid]);
    expect((await result).failure).toContain("exact source passages");
  });

  it("retries an unresolvable review quote against the same unchanged packet", async () => {
    const bad = { ...verdict, caseMatch: { ...verdict.caseMatch, anchors: [{ excerptId: "record", quote: "The first jury found for the owner." }] } };
    const { result, calls } = build([candidate, bad, verdict]);
    expect((await result).packet).toEqual(packet);
    expect(calls.map((call) => call.purpose)).toEqual(["build-case-evidence", "verify-case-evidence", "verify-case-evidence"]);
    expect(JSON.parse(calls[2]!.messages[1]!.content).reviewFeedback).toContain("Case identity: the supporting anchors do not resolve to exact source passages");
  });

  it("repairs a specific chronology defect once and reviews the repaired packet independently", async () => {
    const { result, calls } = build([candidate,
      { ...verdict, sequenceSupported: false, sequenceReason: "The appeal claim bundles events before and after the verdict." },
      { ...candidate, sequence: [] }, verdict
    ]);
    expect((await result).packet?.sequence).toEqual([]);
    expect(calls.map((call) => call.purpose)).toEqual(["build-case-evidence", "verify-case-evidence", "build-case-evidence", "verify-case-evidence"]);
    expect(JSON.parse(calls[2]!.messages[1]!.content).repair.issues).toContain("Chronology: The appeal claim bundles events before and after the verdict.");
  });

  it("accepts empty chronology and disagreement lists even if the reviewer labels the absence false", async () => {
    const { result } = build([{ ...candidate, sequence: [], disagreements: [] }, {
      ...verdict, sequenceSupported: false, sequenceReason: "No event chronology is supplied",
      disagreementsSupported: false, disagreementsReason: "No source disagreement is supplied"
    }]);
    expect((await result).packet?.sequence).toEqual([]);
  });

  it("corrects the source metadata for the same case and keeps excerpt ownership consistent", async () => {
    const episode = { ...packet.episode, title: "The shipping appeal", document: "The actual appeal record" };
    const { result } = build([candidate, { ...verdict, caseMatch: { ...verdict.caseMatch, canonicalEpisode: episode } }]);
    const kept = (await result).packet!;
    expect(kept.episode).toEqual(episode);
    expect(kept.excerpts[0]!.episodeTitle).toBe(episode.title);
    expect(kept.excerpts[0]!.text).toBe(packet.excerpts[0]!.text);
  });

  it.each([
    { ...verdict, claims: verdict.claims.slice(0, 1) },
    { ...verdict, claims: [verdict.claims[0], verdict.claims[0]] },
    { ...verdict, sequenceSupported: false },
    { ...verdict, caseMatch: { ...verdict.caseMatch, supported: false } },
    { ...verdict, unknownsAccurate: false }
  ])("rejects incomplete or negative adjudication %#", async (review) => {
    expect((await build([candidate, review]).result).packet).toBeUndefined();
  });

  it("rejects missing source references before spending on a review", async () => {
    const changed = { ...candidate, claims: candidate.claims.map((claim) => ({ ...claim, excerptIds: ["invented"] })) };
    const { result, calls } = build([changed]);
    expect((await result).failure).toContain("missing passage");
    expect(calls).toHaveLength(1);
    expect(caseEvidenceIssues({ ...packet, sequence: ["invented"] })).toContain("the sequence references a missing claim");
  });

  it("propagates cancellation rather than treating it as a reason to research a replacement", async () => {
    const stopped = new Error("aborted"); stopped.name = "AbortError";
    await expect(build([stopped]).result).rejects.toThrow("aborted");
  });

  it("checks edited prose and refuses findings that cannot be resolved against it", async () => {
    const markdown = "The first jury found for the insurers.";
    const { model, calls } = scriptedDevelopmentModel([{ issues: [{ caseId: packet.id, quote: markdown, reason: "The verdict favored shipowners." }] }]);
    expect(await reviewChapterCaseEvidence({ markdown, packets: [packet], textModel: model })).toEqual([`“${markdown}”: The verdict favored shipowners.`]);
    expect(calls[0]!.messages[1]!.content).toContain(packet.excerpts[0]!.text);
    const bad = scriptedDevelopmentModel([{ issues: [{ caseId: packet.id, quote: "Words absent from the chapter", reason: "Unsupported" }] }]);
    await expect(reviewChapterCaseEvidence({ markdown, packets: [packet], textModel: bad.model })).rejects.toThrow("unresolvable finding");
  });
});
