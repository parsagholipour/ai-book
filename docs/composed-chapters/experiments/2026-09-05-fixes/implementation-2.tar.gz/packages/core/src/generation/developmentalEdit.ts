import { z } from "zod";
import type { TextModelAdapter } from "../adapters/types.js";
import type { BookPlan, CreateProjectInput } from "../schemas/book.js";
import { generateJsonWithRetry } from "./generateJsonWithRetry.js";
import { chapterDegeneracy } from "./chapterIntegrity.js";
import { countReadableWords } from "./proseShape.js";
import { hasFigureFence } from "./figures/figureBlocks.js";

export type DevelopmentChapter = { index: number; title: string; markdown: string };
export type DevelopmentWordBudget = { min: number; target: number; max: number };
const changeSchema = z.object({
  id: z.string().min(1), chapterIndex: z.number().int().positive(),
  startParagraph: z.number().int().positive(), deleteCount: z.number().int().nonnegative(),
  targetWords: z.number().int().nonnegative(), instruction: z.string().min(1)
});
const editPlanSchema = z.object({
  groups: z.array(z.object({ id: z.string().min(1), reason: z.string().min(1), changes: z.array(changeSchema).min(1).max(8) })).max(6)
});
export type DevelopmentEditPlan = z.infer<typeof editPlanSchema>;
export type DevelopmentChange = z.infer<typeof changeSchema>;
export type DevelopmentEditResult = {
  chapters: DevelopmentChapter[];
  plan: DevelopmentEditPlan;
  appliedGroups: string[];
  rejectedGroups: Array<{ id: string; reason: string }>;
  beforeWords: number;
  afterWords: number;
};

export function developmentParagraphs(markdown: string): string[] {
  return markdown.split(/\n\s*\n/).map((paragraph) => paragraph.trim()).filter(Boolean);
}

export function developmentEditPlanIssues(chapters: readonly DevelopmentChapter[], plan: DevelopmentEditPlan): string[] {
  const issues: string[] = [];
  const byChapter = new Map(chapters.map((chapter) => [chapter.index, developmentParagraphs(chapter.markdown)]));
  const occupied = new Map<number, Array<{ start: number; end: number }>>();
  const ids = new Set<string>();
  const groups = new Set<string>();
  let touchedWords = 0;
  const totalWords = chapters.reduce((sum, chapter) => sum + countReadableWords(chapter.markdown), 0);
  for (const group of plan.groups) {
    if (groups.has(group.id)) issues.push("duplicate group ID");
    groups.add(group.id);
    let groupWords = 0;
    for (const change of group.changes) {
      if (ids.has(change.id)) issues.push("duplicate change ID");
      ids.add(change.id);
      const paragraphs = byChapter.get(change.chapterIndex);
      const start = change.startParagraph - 1;
      const end = start + change.deleteCount;
      if (!paragraphs || start > paragraphs.length || end > paragraphs.length) { issues.push(`invalid range ${change.id}`); continue; }
      if (change.deleteCount === 0 && change.targetWords === 0) issues.push(`empty operation ${change.id}`);
      const ranges = occupied.get(change.chapterIndex) ?? [];
      if (ranges.some((range) => start === range.start || (start < range.end && end > range.start))) issues.push(`overlapping range ${change.id}`);
      ranges.push({ start, end });
      occupied.set(change.chapterIndex, ranges);
      const original = paragraphs.slice(start, end).join("\n\n");
      // A figure stays anchored to its paragraph; edits around it are still allowed.
      if (/\[Figure:/i.test(original) || hasFigureFence(original)) issues.push(`range ${change.id} contains a protected figure`);
      const words = Math.max(countReadableWords(original), change.targetWords);
      touchedWords += words;
      groupWords += words;
    }
    if (groupWords > 8000) issues.push(`group ${group.id} exceeds the section rewrite budget`);
  }
  if (occupied.size > Math.min(6, chapters.length)) issues.push("too many chapters selected for developmental rewriting");
  if (touchedWords > Math.max(600, totalWords * 0.3)) issues.push("developmental edits exceed thirty percent of the manuscript");
  return [...new Set(issues)];
}

export function applyDevelopmentChanges(
  chapters: readonly DevelopmentChapter[], changes: readonly DevelopmentChange[], replacements: ReadonlyMap<string, string>
): DevelopmentChapter[] {
  return chapters.map((chapter) => {
    const edits = changes.filter((change) => change.chapterIndex === chapter.index);
    if (!edits.length) return { ...chapter };
    const paragraphs = developmentParagraphs(chapter.markdown);
    for (const edit of [...edits].sort((a, b) => b.startParagraph - a.startParagraph)) {
      const text = replacements.get(edit.id);
      if (text === undefined) throw new Error(`Missing replacement ${edit.id}`);
      paragraphs.splice(edit.startParagraph - 1, edit.deleteCount, ...developmentParagraphs(text));
    }
    return { ...chapter, markdown: paragraphs.join("\n\n") };
  });
}

export async function editManuscriptDevelopment(options: {
  input: CreateProjectInput;
  plan: BookPlan;
  chapters: DevelopmentChapter[];
  wordBudget: DevelopmentWordBudget;
  textModel: TextModelAdapter;
}): Promise<DevelopmentEditResult> {
  const beforeWords = options.chapters.reduce((sum, chapter) => sum + countReadableWords(chapter.markdown), 0);
  const empty: DevelopmentEditResult = { chapters: options.chapters, plan: { groups: [] }, appliedGroups: [], rejectedGroups: [], beforeWords, afterWords: beforeWords };
  if (beforeWords > 110_000) return { ...empty, rejectedGroups: [{ id: "plan", reason: "manuscript exceeds the full-text review budget" }] };
  const result = await generateJsonWithRetry(options.textModel, {
    purpose: "plan-developmental-edit", temperature: 0.2, maxTokens: 10_000, schema: editPlanSchema,
    messages: [
      { role: "system", content: [
        "Read the complete nonfiction manuscript and propose a bounded developmental edit. Identify sections whose cases, explanation or inference overlap, even with different names and wording. Preserve the requested coverage and useful recurrence that changes understanding. You may delete, move, combine, or replace sections, and develop an unanswered question using the available evidence. Do not prescribe uniform openings, closings, paragraph shapes or rhetorical moves.",
        "Return JSON {groups:[{id,reason,changes:[{id,chapterIndex,startParagraph,deleteCount,targetWords,instruction}]}]}. Paragraph indexes are one-based against the supplied original text. deleteCount 0 inserts before startParagraph (length+1 appends); targetWords 0 deletes with no replacement. A move has linked source and destination changes in ONE group: both apply or neither does. Instructions must explain the concrete contribution the replacement adds and which evidence supports it.",
        "At most six groups and six affected chapters, no overlapping ranges. Sum of max(original range words,targetWords) across changes must stay within thirty percent of manuscript words (600-word minimum budget), and within 8000 per group. Never select a paragraph containing a figure stand-in. All unselected prose stays unchanged.",
        "The word budget belongs to the whole book. Compensate for necessary cuts only by developing a named unanswered question or case from the evidence, possibly in another chapter. Never refill the section just cut, pad with a recap, or invent details. Aim within the supplied book min/max; consider the actual current count. Use empty groups when no substantive improvement is warranted."
      ].join(" ") },
      { role: "user", content: JSON.stringify({
        request: options.input.prompt, coverage: options.plan.bookDevelopment?.coverage ?? options.plan.promises,
        development: options.plan.bookDevelopment, wordBudget: options.wordBudget, currentWords: beforeWords,
        evidence: options.plan.dossier?.evidencePackets?.map(({ excerpts: _excerpts, ...packet }) => packet),
        chapters: options.chapters.map((chapter) => ({ index: chapter.index, title: chapter.title, paragraphs: developmentParagraphs(chapter.markdown).map((text, index) => ({ index: index + 1, text })) }))
      }) }
    ]
  });
  const issues = developmentEditPlanIssues(options.chapters, result.data);
  if (issues.length) return { ...empty, plan: result.data, rejectedGroups: [{ id: "plan", reason: issues.join("; ") }] };
  const replacements = new Map<string, string>();
  const accepted: DevelopmentChange[] = [];
  const appliedGroups: string[] = [];
  const rejectedGroups: DevelopmentEditResult["rejectedGroups"] = [];
  for (const group of result.data.groups) {
    const response = await generateJsonWithRetry(options.textModel, {
      purpose: "rewrite-developmental-sections", temperature: Math.min(0.6, options.input.temperature),
      maxTokens: Math.min(30_000, Math.max(4000, group.changes.reduce((sum, change) => sum + change.targetWords, 0) * 3 + 2000)),
      schema: z.object({ replacements: z.array(z.object({ id: z.string(), text: z.string() })).max(8) }),
      messages: [
        { role: "system", content: "Execute this linked group of developmental section edits. Return JSON {replacements:[{id,text}]} with exactly one replacement for every change ID. Return only the replacement section in text, not a whole chapter; deletion returns an empty string. Preserve useful material in a move or combination. Use the supplied evidence for factual additions, retaining attribution and uncertainty. Do not invent scene details, quotes, sources or claims. Follow the book's language and voice. Target each requested word count within twenty percent. Do not introduce headings, commentary, figure blocks or figure stand-ins. All prose outside these ranges is preserved by code." },
        { role: "user", content: JSON.stringify({
          language: options.input.language, voiceGuide: options.plan.voiceGuide, group,
          chapters: options.chapters.filter((chapter) => group.changes.some((change) => change.chapterIndex === chapter.index)),
          caseEvidence: options.plan.dossier?.evidencePackets,
          wordBudget: options.wordBudget
        }) }
      ]
    });
    const byId = new Map(response.data.replacements.map((entry) => [entry.id, entry.text.trim()]));
    const complete = byId.size === group.changes.length && byId.size === response.data.replacements.length && group.changes.every((change) => byId.has(change.id));
    const valid = complete && group.changes.every((change) => {
      const text = byId.get(change.id)!;
      if (change.targetWords === 0) return text === "";
      const words = countReadableWords(text);
      return words >= Math.max(1, change.targetWords * 0.6) && words <= change.targetWords * 1.4 &&
        !hasFigureFence(text) && !/\[Figure:/i.test(text) && !chapterDegeneracy(text, { maxWords: Math.ceil(change.targetWords * 1.4), language: options.input.language }).degenerate;
    });
    if (!valid) { rejectedGroups.push({ id: group.id, reason: "replacement IDs, lengths or prose integrity failed; linked changes kept together" }); continue; }
    for (const [id, text] of byId) replacements.set(id, text);
    accepted.push(...group.changes);
    appliedGroups.push(group.id);
  }
  const chapters = applyDevelopmentChanges(options.chapters, accepted, replacements);
  const afterWords = chapters.reduce((sum, chapter) => sum + countReadableWords(chapter.markdown), 0);
  if (afterWords < options.wordBudget.min || afterWords > options.wordBudget.max) {
    return { ...empty, plan: result.data, rejectedGroups: [...rejectedGroups, ...appliedGroups.map((id) => ({ id, reason: "combined edits violate the whole-book word budget" }))] };
  }
  return { chapters, plan: result.data, appliedGroups, rejectedGroups, beforeWords, afterWords };
}
